package org.smart.board.service;

import org.smart.board.entity.Member;

public interface MemberService {
    // 회원가입
    public int insertMember(Member member);
}
